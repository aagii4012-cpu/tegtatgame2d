// Cloudflare Workers entry — static сайт (assets) + /api/* leaderboard (D1).
// Pages-ийн functions/ хавтас Workers дээр автоматаар ажилладаггүй тул энд нэг нэгээр нь холбоно.
import * as save from "../functions/api/save-score.js";
import * as board from "../functions/api/leaderboard.js";
import * as tegtatSave from "../functions/api/tegtat/save-score.js";
import * as tegtatBoard from "../functions/api/tegtat/leaderboard.js";

const ROUTES = {
  "/api/save-score": save,
  "/api/leaderboard": board,
  "/api/tegtat/save-score": tegtatSave,
  "/api/tegtat/leaderboard": tegtatBoard
};

export default {
  async fetch(request, env, ctx) {
    const url = new URL(request.url);
    const path = url.pathname.replace(/\/+$/, "") || "/";
    const mod = ROUTES[path];
    if (mod) {
      const method = request.method.toUpperCase();
      const name = "onRequest" + method.charAt(0) + method.slice(1).toLowerCase();
      const handler = mod[name] || mod.onRequest;
      const context = { request, env, params: {}, waitUntil: (p) => ctx.waitUntil(p), next: () => env.ASSETS.fetch(request), data: {} };
      return handler(context);
    }
    if (path.startsWith("/api/")) {
      return new Response(JSON.stringify({ ok: false, error: "not_found" }), { status: 404, headers: { "Content-Type": "application/json; charset=utf-8" } });
    }
    return env.ASSETS.fetch(request);
  }
};
