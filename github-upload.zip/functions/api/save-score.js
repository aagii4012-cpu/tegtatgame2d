// POST /api/save-score  { "name": "BAT", "score": 4200 }
// Validates input on the server and stores ONLY name, score, created_at in D1.
import {
  json, errorResponse, normalizeName, validateName, validateScore, dbMissing
} from "./_shared.js";

const MAX_BODY_BYTES = 1024;
const SAME_NAME_COOLDOWN_MS = 5000;

export async function onRequestPost({ request, env }) {
  if (!env.DB) return dbMissing();

  const type = request.headers.get("Content-Type") || "";
  if (!type.toLowerCase().includes("application/json")) {
    return errorResponse(415, "unsupported_media_type", "Content-Type нь application/json байх ёстой.");
  }

  let text;
  try {
    text = await request.text();
  } catch {
    return errorResponse(400, "bad_body", "Хүсэлтийн биеийг уншиж чадсангүй.");
  }
  if (new TextEncoder().encode(text).length > MAX_BODY_BYTES) {
    return errorResponse(413, "body_too_large", "Хүсэлт хэт том байна.");
  }

  let body;
  try {
    body = JSON.parse(text);
  } catch {
    return errorResponse(400, "invalid_json", "JSON буруу байна.");
  }
  if (!body || typeof body !== "object" || Array.isArray(body)) {
    return errorResponse(400, "invalid_body", "JSON объект илгээнэ үү.");
  }

  const name = normalizeName(body.name);
  const nameError = validateName(name);
  if (nameError) return errorResponse(400, "invalid_name", nameError);

  const score = body.score;
  const scoreError = validateScore(score);
  if (scoreError) return errorResponse(400, "invalid_score", scoreError);

  try {
    // Simple anti-spam: same nickname cannot save twice within 5 seconds.
    const since = new Date(Date.now() - SAME_NAME_COOLDOWN_MS).toISOString();
    const recent = await env.DB
      .prepare("SELECT id FROM game_scores WHERE name = ?1 AND created_at > ?2 LIMIT 1")
      .bind(name, since)
      .first();
    if (recent) {
      return errorResponse(429, "too_many_requests", "Хэт ойр ойрхон хадгалж байна. Түр хүлээгээд дахин оролдоно уу.");
    }

    const createdAt = new Date().toISOString();
    const result = await env.DB
      .prepare("INSERT INTO game_scores (name, score, created_at) VALUES (?1, ?2, ?3)")
      .bind(name, score, createdAt)
      .run();
    const id = result.meta && result.meta.last_row_id;

    const rankRow = await env.DB
      .prepare(
        `SELECT COUNT(*) AS better FROM game_scores
         WHERE score > ?1 OR (score = ?1 AND (created_at < ?2 OR (created_at = ?2 AND id < ?3)))`
      )
      .bind(score, createdAt, id)
      .first();
    const rank = (rankRow ? Number(rankRow.better) : 0) + 1;

    return json({ ok: true, id, name, score, created_at: createdAt, rank }, 201);
  } catch (err) {
    console.error("save-score failed", err);
    return errorResponse(500, "db_error", "Оноо хадгалах үед алдаа гарлаа.");
  }
}

export async function onRequest({ request }) {
  // Any method other than POST (onRequestPost takes precedence for POST)
  return errorResponse(405, "method_not_allowed", "Зөвхөн POST хүсэлт зөвшөөрнө.");
}
